function tocaSomAplausos() {
    document.querySelector('#som_tecla_aplausos').play();
}
document.querySelector('.tecla_aplausos').onclick = tocaSomAplausos;


function tocaSomVaia() {
    document.querySelector('#som_tecla_vaia').play();
}
document.querySelector('.tecla_vaia').onclick = tocaSomAplausos;


function tocaSomRisada() {
    document.querySelector('#som_tecla_risada').play();
}
document.querySelector('.tecla_risada').onclick = tocaSomAplausos;


function tocaSomErrado() {
    document.querySelector('#som_tecla_errado').play();
}
document.querySelector('.tecla_errado').onclick = tocaSomErrado;


function tocaSomGrilo() {
    document.querySelector('#som_tecla_grilo').play();
}
document.querySelector('.tecla_grilo').onclick = tocaSomGrilo;


function tocaSomTambores() {
    document.querySelector('#som_tecla_tambores').play();
}
document.querySelector('.tecla_tambores-').onclick = tocaSomTambores;


function tocaSomTrombeta() {
    document.querySelector('#som_tecla_trombetas').play();
}
document.querySelector('.tecla_trombetas').onclick = tocaSomTrombetas;


function tocaSomDinheiro() {
    document.querySelector('#som_tecla_dinheiro').play();
}
document.querySelector('.tecla_dinheiro').onclick = tocaSomDinheiro;


function tocaSomVitoria() {
    document.querySelector('#som_tecla_vitoria').play();
}
document.querySelector('.tecla_vitoria').onclick = tocaSomVitoria;





